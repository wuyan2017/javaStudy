CREATE PROCEDURE yyd_change_phone(IN oldId        INT, IN newId INT, IN oldphone VARCHAR(13), IN newphone VARCHAR(11),
                                  IN alterChannel INT, IN alterPersonId MEDIUMTEXT)
  BEGIN
    
	IF newphone IS NOT NULL AND newphone != '' AND oldphone IS NOT NULL AND oldphone != '' AND oldId IS NOT NULL AND oldId > 0 THEN
		INSERT INTO yyd_users_logout(`user_id`,`username`,`email`,`password`,`paypassword`,`question`,`answer`,`logintime`,`reg_ip`,`reg_time`,`up_ip`,`up_time`,`last_ip`,`last_time`,`second_status`,`status`,`cancel_time`,`openId`,`add_channel`,`cur_channel`,`add_product`,
			`cur_product`,`openId_u`,`yn_exit_web_u`,`yn_exit_web`,`reg_from`,`update_time`)
		SELECT 	`user_id`,`username`,`email`,`password`,`paypassword`,`question`,`answer`,`logintime`,`reg_ip`,`reg_time`,`up_ip`,`up_time`,`last_ip`,`last_time`,`second_status`,`status`,`cancel_time`,`openId`,`add_channel`,`cur_channel`,`add_product`,
			`cur_product`,`openId_u`,`yn_exit_web_u`,`yn_exit_web`,`reg_from`,`update_time`
		FROM yyd_users WHERE user_id = newId;
		
		INSERT INTO yyd_users_info_logout(`id`, `user_id`, `niname`, `sex`, `birthday`, `type_id`, `avatar`, `status`,`invite_userid`, `invite_money`, `realname`, `realname_status`,`realname_times`, `education`, `education_status`, `edu_times`, `phone`,
			`phone_status`, `video_status`, `tender_status`, `province`, `city`, `area`,`web_status`, `question`, `answer`, `creditcard`, `creditcard_status`, `qq`,`sina`, `approve_visit_status`, `human_amount`, `human_amount_status`,
			`human_amount_rank`, `phone_log`, `distribute`, `shanghai`, `super_tender`,`download_channel`, `reg_device_identify`, `human_amount_updatetime`,`human_amount_remark`, `app_version`, `outsourcing`, `lawyer_letter`, `t1`,
			`t2`, `times_borrow`, `outsourcing_name`, `outsourcing_remark`,`oncredit_remark`, `lawyer_remark`, `phone_province`, `phone_city`, `score`,`score_time`, `register_version`, `operator`, `phone_sim`, `add_product`,
			`cur_product`, `add_channel`, `cur_channel`, `uflag`, `app_source`, `u_rank_id`,`u_credit`, `promoter`, `promoter_phone`, `guarantor1`, `guarantor_phone1`,`referees`, `referees_phone`, `referees_relationship`,
			`uzone_human_amount_updatetime`, `uzone_human_amount_remark`,`skip_alipay_authorize`, `alipay_visited`, `more_info_clicked`,`uzone_human_amount`, `uzone_human_amount_status`, `uzone_human_amount_rank`,
			`u_status`, `is_sendmsg`, `is_lightning_cert`, `is_send_mail`, `update_time`)
		SELECT `id`, `user_id`, `niname`, `sex`, `birthday`, `type_id`, `avatar`, `status`,`invite_userid`, `invite_money`, `realname`, `realname_status`,`realname_times`, `education`, `education_status`, `edu_times`, `phone`,
			`phone_status`, `video_status`, `tender_status`, `province`, `city`, `area`,`web_status`, `question`, `answer`, `creditcard`, `creditcard_status`, `qq`,`sina`, `approve_visit_status`, `human_amount`, `human_amount_status`,
			`human_amount_rank`, `phone_log`, `distribute`, `shanghai`, `super_tender`,`download_channel`, `reg_device_identify`, `human_amount_updatetime`,`human_amount_remark`, `app_version`, `outsourcing`, `lawyer_letter`, `t1`,
			`t2`, `times_borrow`, `outsourcing_name`, `outsourcing_remark`,`oncredit_remark`, `lawyer_remark`, `phone_province`, `phone_city`, `score`,`score_time`, `register_version`, `operator`, `phone_sim`, `add_product`,
			`cur_product`, `add_channel`, `cur_channel`, `uflag`, `app_source`, `u_rank_id`,`u_credit`, `promoter`, `promoter_phone`, `guarantor1`, `guarantor_phone1`,`referees`, `referees_phone`, `referees_relationship`,
			`uzone_human_amount_updatetime`, `uzone_human_amount_remark`,`skip_alipay_authorize`, `alipay_visited`, `more_info_clicked`,`uzone_human_amount`, `uzone_human_amount_status`, `uzone_human_amount_rank`,
			`u_status`, `is_sendmsg`, `is_lightning_cert`, `is_send_mail`, `update_time`
		FROM yyd_users_info WHERE user_id = newId;
		
		UPDATE yyd_users_info SET phone = newphone,phone_log=CONCAT(IFNULL(phone_log,''),oldphone) WHERE phone = oldphone AND user_id = oldId;
		UPDATE yyd_users SET username = CONCAT(newphone,'ing') WHERE username = oldphone AND user_id = oldId;
		INSERT INTO yyd_users_phone_alter(user_id,orgin_phone,alter_phone,alter_channel,alter_person_id,ADDTIME) VALUES(oldId,oldphone,newphone,alterChannel,alterPersonId,UNIX_TIMESTAMP());        
	END IF;
		
    UPDATE yyd_users SET username = REPLACE(username,"ing","") WHERE user_id = oldId;
END;
